/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package creacion;

import modelo.Liquor;
import modelo.Wine;

/**
 * Fábrica concreta para crear registros de vinos en el catálogo de software.
 */
public class CreadorVino implements CreadorLicores {
    @Override
    public Liquor crearLicor(String name, double price, int stock, String brand, Object specificParam) {
        int year = 2020;
        if (specificParam instanceof Number) {
            year = ((Number) specificParam).intValue();
        }
        return new Wine(null, name, price, stock, brand, year);
    }
}
