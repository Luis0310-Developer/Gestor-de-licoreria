/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package creacion;

import modelo.Beer;
import modelo.Liquor;

/**
 * Fábrica concreta para crear registros de cervezas en el catálogo de software.
 */
public class CreadorCerveza implements CreadorLicores {
    @Override
    public Liquor crearLicor(String name, double price, int stock, String brand, Object specificParam) {
        double alcoholPercentage = 0.0;
        if (specificParam instanceof Number) {
            alcoholPercentage = ((Number) specificParam).doubleValue();
        }
        return new Beer(null, name, price, stock, brand, alcoholPercentage);
    }
}
