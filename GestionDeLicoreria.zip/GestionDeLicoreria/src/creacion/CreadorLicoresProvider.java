/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package creacion;


import modelo.Liquor;
import java.util.HashMap;
import java.util.Map;

/**
 * Proveedor y Registro de creadores de licores.
 * Aplica el principio OCP: permite registrar nuevos creadores sin alterar
 * la clase.
 */
public class CreadorLicoresProvider {
    private static final Map<String, CreadorLicores> creadores = new HashMap<>();

    static {
        registrarCreador("wine", new CreadorVino());
        registrarCreador("beer", new CreadorCerveza());
    }

    /**
     * Registra un nuevo creador.
     */
    public static void registrarCreador(String type, CreadorLicores creador) {
        creadores.put(type.toLowerCase(), creador);
    }

    /**
     * Obtiene el creador correspondiente.
     */
    public static CreadorLicores getCreador(String type) {
        CreadorLicores creador = creadores.get(type.toLowerCase());
        if (creador == null) {
            throw new IllegalArgumentException("No se ha registrado ningún creador para el tipo: " + type);
        }
        return creador;
    }

    /**
     * Método helper simplificado para instanciar directamente un licor usando el creador registrado.
     */
    public static Liquor crearLicor(String type, String name, double price, int stock, 
                                     String brand, Object specificParam) {
        CreadorLicores creador = getCreador(type);
        return creador.crearLicor(name, price, stock, brand, specificParam);
    }
}
