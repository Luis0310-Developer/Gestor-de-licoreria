/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package creacion;
import modelo.Liquor;

public interface CreadorLicores {
        /**
     * Crea una instancia de Licor.
     */
    Liquor crearLicor(String name, double price, int stock, String brand, Object specificParam);
}


