/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistencia;
import modelo.Liquor;
import java.util.List;

/**
 * Interfaz LiquorDAO.
 * Aplica el principio ISP (Interface Segregation Principle): está especializada en persistencia de licores.
 * Aplica el principio DIP (Inversión de Dependencias): permite que la lógica dependa de una abstracción
 * y no de una base de datos específica.
 */
public interface LiquorDAO {
    /**
     * Agrega un nuevo licor al almacenamiento.
     */
    void save(Liquor liquor);

    /**
     * Busca un licor por su ID único.
     */
    Liquor findById(Long id);

    /**
     * Obtiene todos los licores en el catálogo.
     */
    List<Liquor> findAll();

    /**
     * Actualiza la información de un licor existente (modificaciones de precio, stock, etc.).
     */
    void update(Liquor liquor);

    /**
     * Quita un licor del almacenamiento según su ID.
     */
    void delete(Long id);
}
