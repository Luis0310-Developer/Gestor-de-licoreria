/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import modelo.Liquor;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementación en memoria (RAM) de la interfaz LiquorDAO.
 * Simula una base de datos utilizando una lista simple.
 */
public class InMemoryLiquorDAO implements LiquorDAO {
    private final List<Liquor> database = new ArrayList<>();
    private long nextId = 1;

    @Override
    public synchronized void save(Liquor liquor) {
        if (liquor == null) {
            throw new IllegalArgumentException("El licor a guardar no puede ser nulo.");
        }
        if (liquor.getId() == null) {
            liquor.setId(nextId++);
        }
        database.add(liquor);
    }

    @Override
    public synchronized Liquor findById(Long id) {
        if (id == null) return null;
        for (Liquor l : database) {
            if (id.equals(l.getId())) {
                return l;
            }
        }
        return null;
    }

    @Override
    public synchronized List<Liquor> findAll() {
        return new ArrayList<>(database);
    }

    @Override
    public synchronized void update(Liquor liquor) {
        if (liquor == null || liquor.getId() == null) {
            throw new IllegalArgumentException("El licor a actualizar debe tener un ID válido.");
        }
        Liquor existente = findById(liquor.getId());
        if (existente == null) {
            throw new IllegalStateException("No se puede actualizar: no existe un licor registrado con el ID " + liquor.getId());
        }
        int index = database.indexOf(existente);
        database.set(index, liquor);
    }

    @Override
    public synchronized void delete(Long id) {
        if (id == null) return;
        Liquor existente = findById(id);
        if (existente != null) {
            database.remove(existente);
        }
    }
}
