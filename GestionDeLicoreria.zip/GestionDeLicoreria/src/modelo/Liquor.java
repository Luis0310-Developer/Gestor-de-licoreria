/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


/**
 * Clase abstracta base que representa un Licor genérico.
 * Aplica el principio LSP (Liskov Substitution Principle): cualquier subclase de Liquor
 * puede usarse en su lugar sin romper la lógica del sistema.
 */
public abstract class Liquor {
    private Long id;
    private String name;
    private double price;
    private int stock;
    private String brand;

    public Liquor() {
    }

    public Liquor(Long id, String name, double price, int stock, String brand) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.brand = brand;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * Retorna el tipo específico de licor (por ejemplo, "Vino", "Cerveza").
     */
    public abstract String getLiquorType();

    @Override
    public String toString() {
        return String.format("[%s] ID: %d | %s (%s) | Precio: $%.2f | Stock: %d",
                getLiquorType(), id, name, brand, price, stock);
    }
}
