/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * Representa la categoría de Vinos.
 * Extiende la clase base Liquor e introduce el atributo de año.
 */
public class Wine extends Liquor {
    private int year;

    public Wine() {
        super();
    }

    public Wine(Long id, String name, double price, int stock, String brand, int year) {
        super(id, name, price, stock, brand);
        this.year = year;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String getLiquorType() {
        return "Vino";
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Año: %d", year);
    }
}
