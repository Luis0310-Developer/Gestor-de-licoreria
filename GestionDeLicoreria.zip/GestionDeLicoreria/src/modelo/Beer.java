/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * Representa la categoría de Cervezas.
 * Extiende la clase base Liquor e introduce el atributo de porcentaje de alcohol.
 */
public class Beer extends Liquor {
    private double alcoholPercentage;

    public Beer() {
        super();
    }

    public Beer(Long id, String name, double price, int stock, String brand, double alcoholPercentage) {
        super(id, name, price, stock, brand);
        this.alcoholPercentage = alcoholPercentage;
    }

    public double getAlcoholPercentage() {
        return alcoholPercentage;
    }

    public void setAlcoholPercentage(double alcoholPercentage) {
        this.alcoholPercentage = alcoholPercentage;
    }

    @Override
    public String getLiquorType() {
        return "Cerveza";
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Alc: %.1f%%", alcoholPercentage);
    }
}
