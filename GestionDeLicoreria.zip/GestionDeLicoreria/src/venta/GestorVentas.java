/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package venta;

import modelo.Liquor;
import persistencia.LiquorDAO;

/**
 * GestorVentas.
 * Aplica el principio SRP (Responsabilidad Única): se encarga exclusivamente de las reglas
 * de negocio de la venta de licores al cliente y de la gestión física de su inventario.
 * Aplica DIP: interactúa con la persistencia mediante la interfaz LiquorDAO.
 */
public class GestorVentas {

    /**
     * Procesa la venta de un licor a un cliente.
     * Valida stock, reduce la cantidad e imprime la boleta de venta.
     */
    public void procesarVenta(Long id, int cantidad, LiquorDAO dao) {
        System.out.printf(">>> Solicitud de Venta: ID %d | Cantidad: %d unidades...%n", id, cantidad);
        Liquor liquor = dao.findById(id);

        if (liquor == null) {
            System.out.println("  [ERROR] El licor solicitado no existe en el catálogo.");
            return;
        }

        if (liquor.getStock() < cantidad) {
            System.out.printf("  [RECHAZADO] Stock insuficiente para '%s'. Disponible: %d | Solicitado: %d%n",
                    liquor.getName(), liquor.getStock(), cantidad);
            return;
        }

        // Reducimos el stock y actualizamos en persistencia
        liquor.setStock(liquor.getStock() - cantidad);
        dao.update(liquor);

        double total = liquor.getPrice() * cantidad;
        System.out.println("  [COMPLETADO] ¡Venta exitosa!");
        System.out.printf("  ------- BOLETA DE VENTA -------%n");
        System.out.printf("  Producto: %s (%s)%n", liquor.getName(), liquor.getBrand());
        System.out.printf("  Precio Unitario: $%.2f%n", liquor.getPrice());
        System.out.printf("  Cantidad: %d%n", cantidad);
        System.out.printf("  Total Cobrado: $%.2f%n", total);
        System.out.printf("  Stock Restante: %d%n", liquor.getStock());
        System.out.printf("  --------------------------------%n");
    }

    /**
     * Incrementa/agrega stock a un licor existente.
     */
    public void agregarStock(Long id, int cantidad, LiquorDAO dao) {
        System.out.printf(">>> Reabasteciendo Stock: ID %d | Adición: +%d unidades...%n", id, cantidad);
        Liquor liquor = dao.findById(id);

        if (liquor == null) {
            System.out.println("  [ERROR] No se puede reabastecer. El licor no existe.");
            return;
        }

        liquor.setStock(liquor.getStock() + cantidad);
        dao.update(liquor);
        System.out.printf("  [COMPLETADO] Stock actualizado de '%s'. Nuevo stock: %d%n",
                liquor.getName(), liquor.getStock());
    }

    /**
     * Cambia el precio de venta de un licor.
     */
    public void modificarPrecio(Long id, double nuevoPrecio, LiquorDAO dao) {
        System.out.printf(">>> Cambiando Precio: ID %d | Nuevo Precio: $%.2f...%n", id, nuevoPrecio);
        Liquor liquor = dao.findById(id);

        if (liquor == null) {
            System.out.println("  [ERROR] No se puede modificar el precio. El licor no existe.");
            return;
        }

        double precioAnterior = liquor.getPrice();
        liquor.setPrice(nuevoPrecio);
        dao.update(liquor);
        System.out.printf("  [COMPLETADO] Precio de '%s' modificado. Anterior: $%.2f | Nuevo: $%.2f%n",
                liquor.getName(), precioAnterior, nuevoPrecio);
    }
}
