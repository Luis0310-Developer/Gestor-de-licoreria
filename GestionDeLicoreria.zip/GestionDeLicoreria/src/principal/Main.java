/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package principal;

import creacion.CreadorLicoresProvider;
import modelo.Liquor;
import persistencia.InMemoryLiquorDAO;
import persistencia.LiquorDAO;
import venta.GestorVentas;

/**
 * Clase principal de inicio. Demuestra la funcionalidad del Gestor de Ventas e
 * Inventario de Licores: - Agregar licores al inventario (DAO.save) - Quitar
 * licores del inventario (DAO.delete) - Procesar ventas con validación de
 * existencias (GestorVentas.procesarVenta) - Agregar stock
 * (GestorVentas.agregarStock) - Manipular precios
 * (GestorVentas.modificarPrecio) - Todo ello desacoplado bajo los principios
 * SOLID.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("==========================================================");
        System.out.println("     GESTOR DE LICORERIA SIMPLE (VENTAS E INVENTARIO)     ");
        System.out.println("==========================================================\n");

        // 1. Inicialización de la base de datos (RAM) y el gestor de ventas (DIP)
        LiquorDAO liquorDAO = new InMemoryLiquorDAO();
        GestorVentas gestorVentas = new GestorVentas();

        // 2. Creación e incorporación de licores al catálogo (Abstract Factory + DAO.save)
        System.out.println("--- 1. Cargar Catálogo Inicial de Licores ---");
        Liquor vino1 = CreadorLicoresProvider.crearLicor("wine", "Rutini Malbec", 120.0, 10, "Rutini", 2018);
        Liquor vino2 = CreadorLicoresProvider.crearLicor("wine", "Casillero del Diablo", 45.0, 15, "Concha y Toro", 2020);
        Liquor cerveza1 = CreadorLicoresProvider.crearLicor("beer", "Temple IPA", 12.5, 50, "Temple", 6.2);

        liquorDAO.save(vino1);
        liquorDAO.save(vino2);
        liquorDAO.save(cerveza1);

        mostrarInventario(liquorDAO);

        // 3. Simulación de Ventas (GestorVentas.procesarVenta)
        System.out.println("\n--- 2. Simulación de Procesamiento de Ventas ---");
        // Venta válida
        gestorVentas.procesarVenta(1L, 3, liquorDAO); // Vende 3 botellas de Rutini (queda stock 7)
        // Venta inválida por falta de stock
        gestorVentas.procesarVenta(2L, 20, liquorDAO); // Casillero solo tiene 15, debe fallar

        // 4. Modificación de Stock (Agregar stock)
        System.out.println("\n--- 3. Modificación de Inventario (Agregar Stock) ---");
        gestorVentas.agregarStock(2L, 10, liquorDAO); // Agrega 10 a Casillero (nuevo stock 25)
        // Re-intento de venta rechazada previamente
        gestorVentas.procesarVenta(2L, 20, liquorDAO); // Ahora sí debe poder vender 20 (queda stock 5)

        // 5. Modificación de Precios (Manipular precios)
        System.out.println("\n--- 4. Modificación de Precios ---");
        gestorVentas.modificarPrecio(3L, 14.0, liquorDAO); // Temple sube de 12.5 a 14.0

        // 6. Eliminar un producto del catálogo (DAO.delete)
        System.out.println("\n--- 5. Quitar Licor del Catálogo ---");
        System.out.println("Borrando del sistema la Cerveza Temple (ID 3)...");
        liquorDAO.delete(3L);

        // Mostrar estado final
        mostrarInventario(liquorDAO);
    }

    private static void mostrarInventario(LiquorDAO dao) {
        System.out.println("\n--- ESTADO ACTUAL DEL INVENTARIO EN BASE DE DATOS ---");
        if (dao.findAll().isEmpty()) {
            System.out.println("  [Vacio] No hay licores registrados en el catálogo.");
        } else {
            for (Liquor liquor : dao.findAll()) {
                System.out.println("  " + liquor);
            }
        }
        System.out.println("-----------------------------------------------------");
    }
}
